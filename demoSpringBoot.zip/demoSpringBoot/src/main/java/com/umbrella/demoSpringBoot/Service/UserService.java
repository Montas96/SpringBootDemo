package com.umbrella.demoSpringBoot.Service;

import com.umbrella.demoSpringBoot.Domain.User;

public interface UserService {
    public abstract User createUser(User user);
    User getUser(String id);
}
