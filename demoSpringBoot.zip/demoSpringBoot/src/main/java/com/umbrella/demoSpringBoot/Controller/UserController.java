package com.umbrella.demoSpringBoot.Controller;

import com.umbrella.demoSpringBoot.Controller.Exception.UserNotFoundException;
import com.umbrella.demoSpringBoot.Domain.User;
import com.umbrella.demoSpringBoot.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class UserController {

    @Autowired
    private UserService userService;


    @PostMapping("api/user")
    public ResponseEntity<User> createUser(@RequestParam(value = "name", required = false, defaultValue = "honey") String name){
        return ResponseEntity.ok().build();
    };
    @GetMapping("api/user/{userId}")
    public ResponseEntity<User> getUserById(@PathVariable String userId){
        return ResponseEntity.ok(userService.getUser(userId));
    };
    @RequestMapping(value = "/products/{id}", method = RequestMethod.PUT)
    public ResponseEntity<Object> updateUser() {
        throw new UserNotFoundException();
    }
}
